# stable_marriage
Stable Marriage Problem - AI class assignment

========================================================================
                        T1 Casais Ideais
========================================================================
= FACIN - PUCRS														                             =
= Inteligencia Artificial					                                     =
= Date:	   25/03/2018												                           =
= Authors: Guilherme Korol & Matheus Storck		                         =
========================================================================

////////////////////////////////////////////////////////////////////////

Video demo: https://youtu.be/uzgQ-aJOOTc
